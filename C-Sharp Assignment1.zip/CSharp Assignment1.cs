// PROGRAM 1----------------------------------------------------------------------------------------------

namespace AllOperations
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter 1st number");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2nd number");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the operation you want to performed");
            Console.WriteLine("Press A for Addition");
            Console.WriteLine("Press S for Subtraction");
            Console.WriteLine("Press M for Multiplication");
            Console.WriteLine("Press D for Division \n");
            int operation = Convert.ToChar(Console.ReadLine());

            int result = 0;
            switch (operation)
            {
                case 'A':
                    {
                        result = Addition(num1, num2);
                        break;
                    }
                case 'S':
                    {
                        result = Subtraction(num1, num2);
                        break;
                    }
                case 'M':
                    {
                        result = Multiplication(num1, num2);
                        break;
                    }
                case 'D':
                    {
                        result = Division(num1, num2);
                        break;
                    }
                default:
                    Console.WriteLine("Wrong action!! try again");
                    break;
            }
            Console.WriteLine("The result is {0}", result);
            Console.ReadKey();
        }
        public static int Addition(int num1, int num2)
        {
            int result = num1 + num2;
            return result;
        }
        public static int Subtraction(int num1, int num2)
        {
            int result = num1 - num2;
            return result;
        }
        public static int Multiplication(int num1, int num2)
        {
            int result = num1 * num2;
            return result;
        }
        public static int Division(int num1, int num2)
        {
            int result = num1 / num2;
            return result;
        }
    }
}


// PROGRAM 2------------------------------------------------------------------------------------------------------

namespace HighestMarks
{
    class Topper
    {
        static void Main()
        {
            Double highestmarks = 0;
            int k = 0;
            for (int i = 1; i <= 5; i++)
            {

                Console.WriteLine("Student {0}  please enter your average marks", i);
                Double j = Convert.ToDouble(Console.ReadLine());
                if (j > highestmarks)
                {
                    highestmarks = j;
                    k = i;
                }
            }
            Console.WriteLine("The highest marks are {0} of student number {1}", highestmarks, k);
        }
    }
}

// PROGRAM 3------------------------------------------------------------------------------------------------------------

namespace SumUsingParam
{
    public class MyClass
    {

        public static void UseParams(params int[] list)
        {
            int sum = 0;
            for (int i = 0; i < list.Length; i++)
            {

                sum += list[i];
            }
            Console.WriteLine("the sum of all numbers is {0}", sum);
        }
        static void Main()
        {
            UseParams(1, 2, 3, 6, 8, 56);
        }
    }
}

// PROGRAM 4--------------------------------------------------------------------------------------------------------------

namespace Swaping
{
    public static class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter the first number");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second number ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            num1 = num1 + num2;
            num2 = num1 - num2;
            num1 = num1 - num2;
            Console.WriteLine("first number is : {0}", num1);
            Console.WriteLine("second number is : {0}", num2);
        }
    }
}

// PROGRAM 5--------------------------------------------------------------------------------------------------

namespace Circle
{
    public static class Program
    {
        static void Main()
        {
            Double pi = 3.14;
            Console.WriteLine("enter the radius of circle :");
            Double r = Convert.ToDouble(Console.ReadLine());
            Double Area = pi * r * r;
            Console.WriteLine("The approximated area of circle is {0}", Area);
        }
    }
}

// PROGRAM 6----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace ConsoleApp
    {

        struct Books
        {
            public enum bookType
            {
                Magazine, Novel, ReferenceBook, Miscellaneous
            }

            private string _Title;
            private int _price;
            private int _bookId;
            private bookType _bookType;


            public string Title { get; set; }

            public int Price { get; set; }
            public int BookId { get; set; }
            public bookType BookType { get; set; }

        }
        class BookStructureAndEnum
        {
            public static void Main()
            {
                Books book = new Books();

                Console.Write("Enter Book Id :");
                book.BookId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Book Title:");
                book.Title = (Console.ReadLine());

                Console.Write("Enter Book Price:");
                book.Price = Convert.ToInt32(Console.ReadLine());



                book.BookType = Books.bookType.Magazine;
                Console.WriteLine("------------");
                Console.WriteLine("------------");
                Console.WriteLine("The Book ID :" + book.BookId);
                Console.WriteLine("The Book Title:" + book.Title);
                Console.WriteLine("The Book Price:" + book.Price);
                Console.WriteLine("The Book BookType:" + book.BookType);
            }
        }
    }
}

